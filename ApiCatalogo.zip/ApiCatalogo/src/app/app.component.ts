import { Component } from '@angular/core';
import { ProdutoService } from './services/produto.service';
import { CategoriaService } from './services/categoria.service';
import { Produto } from './models/produto';
import { Categoria } from './models/categoria';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
}) 

export class AppComponent {
  title = 'ApiCatalogo';

  produto = {} as Produto;
  produtos: Produto[] = [];
 
  
  constructor(private produtoService: ProdutoService, private categoriaService: CategoriaService) {} 
  ngOnInit() {
    
    this.getProdutos();
   

  }
  
  saveProduto(form: NgForm) {
    if (this.produto.ProdutoId !== undefined) {
      this.produtoService.updateProduto(this.produto).subscribe(() => {
        this.cleanForm(form);
      });
    } else {
      this.produtoService.saveProduto(this.produto).subscribe(() => {
        this.cleanForm(form);
      });
    }
  }

  SaveProduto(n: string){
    this.produto.Nome= n;
    this.produtoService.saveProduto(this.produto);
  }

  getProdutos() {
    this.produtoService.getProdutos().subscribe((produto: Produto[]) => {
      this.produtos = this.produtos;
    });
  }

  deleteProduto(produto: Produto) {
    this.produtoService.deletaProduto(produto).subscribe(() => {
      this.getProdutos();
    });
  }

  editProduto(produto: Produto) {
    this.produto = { ...produto };
  }

  cleanForm(form: NgForm) {
    this.getProdutos();
    form.resetForm();
    this.produto = {} as Produto;
    this.getCategoria();
    this.categoria = {} as Categoria;
  }

  categoria = {} as Categoria;
  categorias: Categoria[] = [];

  saveCategoria(form: NgForm) {
    if (this.categoria.CategoriaId !== undefined) {
      this.categoriaService.updateCategoria(this.categoria).subscribe(() => {
        this.cleanForm(form);
      });
    } else {
      this.categoriaService.saveCategoria(this.categoria).subscribe(() => {
        this.cleanForm(form);
      });
    }
  }
  getCategoria() {
    this.categoriaService.getCategoria().subscribe((categoria: Categoria[]) => {
      this.categorias = this.categorias;
    });
  }

  SaveCategoria(n: string){
    this.categoria.Nome= n;
    this.categoriaService.saveCategoria(this.categoria);
  }

 

  deleteCategoria(categoria: Categoria) {
    this.categoriaService.deletaCateogria(categoria).subscribe(() => {
      this.getCategoria();
    });
  }

  editCategoria(categoria: Categoria) {
    this.categoria = { ...categoria};
  }

  

}
