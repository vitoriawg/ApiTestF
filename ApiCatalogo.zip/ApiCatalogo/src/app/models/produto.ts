export interface Produto {
    ProdutoId?: number;
    Nome?: string;
    Descricao?: string;
    Preco?: number;
    Estoque?: number;
    DataCadastro?: Date;
    CategoriaId?: number;
    ImagemUrl?: string;

}
