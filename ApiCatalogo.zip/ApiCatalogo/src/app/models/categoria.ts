export interface Categoria {
    CategoriaId?: number;
    Nome?: string;
    ImagemUrl?: string;
}
